const REFRESH_ALARM = "refresh-block-rules";
const REFRESH_MINUTES = 0.5;
const BLOCKED_PAGE = "/pages/blocked/blocked.html";
const SCHEDULE_KEY = "scheduleBlockerSchedule";
const STATE_KEY = "scheduleBlockerState";
const USAGE_KEY = "scheduleBlockerUsage";
const USAGE_HISTORY_KEY = "scheduleBlockerUsageHistory";
const TRACKING_KEY = "scheduleBlockerTracking";
const SCREEN_TRACKING_KEY = "scheduleBlockerScreenTracking";
const SETTINGS_KEY = "websiteTrackerSettings";
const POMODORO_KEY = "scheduleBlockerPomodoro";
const POMODORO_HISTORY_KEY = "scheduleBlockerPomodoroHistory";
const POMODORO_ALARM = "schedule-blocker-pomodoro";
const MAX_POMODORO_HISTORY_DAYS = 90;
const MAX_POMODORO_HISTORY_ITEMS = 500;
const MAX_USAGE_HISTORY_DAYS = 30;
const MAX_TRACKING_GAP_SECONDS = 2 * 60;
const DAY_NAMES = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
let extensionPopupOpenCount = 0;

const DAY_ALIASES = new Map([
  ["sun", 0],
  ["sunday", 0],
  ["mon", 1],
  ["monday", 1],
  ["tue", 2],
  ["tues", 2],
  ["tuesday", 2],
  ["wed", 3],
  ["wednesday", 3],
  ["thu", 4],
  ["thur", 4],
  ["thurs", 4],
  ["thursday", 4],
  ["fri", 5],
  ["friday", 5],
  ["sat", 6],
  ["saturday", 6]
]);

chrome.runtime.onInstalled.addListener(() => {
  void initialize();
});

chrome.runtime.onStartup.addListener(() => {
  void initialize();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === REFRESH_ALARM) {
    void tick();
  } else if (alarm.name === POMODORO_ALARM) {
    void stopPomodoro({ completed: true });
  }
});

chrome.tabs.onActivated.addListener(() => {
  void tick({ requireCurrentMatch: false });
});

chrome.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
  if (changeInfo.url || changeInfo.status === "complete") {
    void tick({ requireCurrentMatch: !tab?.active });
  }
});

chrome.windows.onFocusChanged.addListener(() => {
  void tick({ requireCurrentMatch: false });
});

chrome.runtime.onConnect.addListener((port) => {
  if (port?.name !== "focus-tracker-popup") {
    return;
  }

  extensionPopupOpenCount += 1;
  void accrueActiveUsage({ trackCurrent: false, requireCurrentMatch: true });

  port.onDisconnect.addListener(() => {
    extensionPopupOpenCount = Math.max(0, extensionPopupOpenCount - 1);

    if (extensionPopupOpenCount === 0) {
      void tick();
    }
  });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "get-schedule-data") {
    accrueScreenUsage()
      .then(() => refreshRules())
      .then(() => getScheduleData())
      .then((data) => sendResponse({ ok: true, ...data }))
      .catch((error) => sendResponse({ ok: false, error: serializeError(error) }));

    return true;
  }

  if (message?.type === "save-schedule") {
    accrueScreenUsage()
      .then(() => saveSchedule(message.schedule))
      .then((schedule) => Promise.all([refreshRules(), loadPublicSettings()]).then(([state, settings]) => ({ schedule, state, settings })))
      .then((data) => sendResponse({ ok: true, ...data }))
      .catch((error) => sendResponse({ ok: false, error: serializeError(error) }));

    return true;
  }

  if (message?.type === "save-settings") {
    saveSettings(message.settings)
      .then((settings) => sendResponse({ ok: true, settings }))
      .catch((error) => sendResponse({ ok: false, error: serializeError(error) }));

    return true;
  }

  if (message?.type === "refresh-rules") {
    accrueScreenUsage()
      .then(() => refreshRules())
      .then((state) => sendResponse({ ok: true, state }))
      .catch((error) => sendResponse({ ok: false, error: serializeError(error) }));

    return true;
  }

  if (message?.type === "get-usage-data") {
    accrueScreenUsage()
      .then(() => getUsageData())
      .then((data) => sendResponse({ ok: true, ...data }))
      .catch((error) => sendResponse({ ok: false, error: serializeError(error) }));

    return true;
  }

  if (message?.type === "get-site-status") {
    getSiteStatus(message.domain)
      .then((status) => sendResponse({ ok: true, status }))
      .catch((error) => sendResponse({ ok: false, error: serializeError(error) }));

    return true;
  }

  if (message?.type === "validate-pin") {
    loadSettings()
      .then(async (settings) => {
        return {
          configured: Boolean(settings.pinHash),
          valid: await verifyPin(message.pin, settings)
        };
      })
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: serializeError(error) }));

    return true;
  }

  if (message?.type === "add-extra-time") {
    addExtraTime(message.domain, message.minutes, message.pin, _sender?.tab?.id)
      .then(() => refreshRules())
      .then(() => getSiteStatus(message.domain))
      .then((status) => {
        const targetUrl = getResumeTargetUrl(message.targetUrl, message.domain);

        if (status?.isBlocked) {
          throw new Error("Extra time was saved, but this website is still blocked.");
        }

        sendResponse({ ok: true, status, targetUrl });
      })
      .catch((error) => sendResponse({ ok: false, error: serializeError(error) }));

    return true;
  }

  if (message?.type === "cut-off-site") {
    cutOffSite(message.domain)
      .then(() => refreshRules())
      .then(() => getSiteStatus(message.domain))
      .then((status) => sendResponse({ ok: true, status }))
      .catch((error) => sendResponse({ ok: false, error: serializeError(error) }));

    return true;
  }

  if (message?.type === "get-pomodoro-state") {
    getPomodoroStateForResponse()
      .then((pomodoro) => sendResponse({ ok: true, pomodoro }))
      .catch((error) => sendResponse({ ok: false, error: serializeError(error) }));

    return true;
  }

  if (message?.type === "get-pomodoro-stats") {
    getPomodoroStats(message.date)
      .then((stats) => sendResponse({ ok: true, stats }))
      .catch((error) => sendResponse({ ok: false, error: serializeError(error) }));

    return true;
  }

  if (message?.type === "start-pomodoro") {
    startPomodoro(message)
      .then((data) => sendResponse({ ok: true, ...data }))
      .catch((error) => sendResponse({ ok: false, error: serializeError(error) }));

    return true;
  }

  if (message?.type === "stop-pomodoro") {
    stopPomodoro()
      .then((data) => sendResponse({ ok: true, ...data }))
      .catch((error) => sendResponse({ ok: false, error: serializeError(error) }));

    return true;
  }

  return false;
});

async function initialize() {
  await chrome.alarms.create(REFRESH_ALARM, { periodInMinutes: REFRESH_MINUTES });
  await restorePomodoroAlarm();
  await refreshRules();
}

async function tick({ requireCurrentMatch = true } = {}) {
  try {
    await accrueScreenUsage();
    await accrueActiveUsage({ requireCurrentMatch });
    const state = await refreshRules();
    await enforceActiveTabBlock(state);
  } catch {
  }
}

async function refreshRules() {
  try {
    const [schedule, usage, settings, pomodoro] = await Promise.all([
      loadSchedule(),
      getUsage(),
      loadSettings(),
      loadPomodoroState()
    ]);
    const now = getTimeParts(schedule.timezone);
    const activeSites = pomodoro.active && pomodoro.mode === "standard"
      ? getPomodoroStandardSites(schedule)
      : pomodoro.active && pomodoro.mode === "strict"
        ? []
        : getActiveSites(schedule, now, usage, settings);
    const activeExceptionDomains = getExceptionDomains(activeSites);
    const rules = pomodoro.active && pomodoro.mode === "strict"
      ? [createStrictPomodoroRule(pomodoro)]
      : activeSites.map((site, index) => createRedirectRule(index + 1, site, activeExceptionDomains));

    await replaceDynamicRules(rules);

    const state = {
      activeSites,
      error: "",
      lastUpdated: Date.now(),
      pomodoro,
      siteUsage: getSiteUsageStates(schedule, now, usage, settings, pomodoro),
      timezone: schedule.timezone || "local"
    };

    await saveState(state);
    await updateBadge(pomodoro.active ? "F" : activeSites.length);
    return state;
  } catch (error) {
    let fallbackPomodoro = normalizePomodoroState();

    try {
      fallbackPomodoro = await loadPomodoroState();
    } catch (_pomodoroError) {
    }

    await replaceDynamicRules([]);
    await saveState({
      activeSites: [],
      error: serializeError(error),
      lastUpdated: Date.now(),
      pomodoro: fallbackPomodoro,
      siteUsage: [],
      timezone: "local"
    });
    await updateBadge(null, true);
    throw error;
  }
}

async function loadSchedule() {
  const stored = await chrome.storage.local.get(SCHEDULE_KEY);

  if (stored[SCHEDULE_KEY]) {
    return stored[SCHEDULE_KEY];
  }

  return {
    timezone: "local",
    sites: []
  };
}

async function getScheduleData() {
  const [schedule, settings, pomodoro, stored] = await Promise.all([
    loadSchedule(),
    loadPublicSettings(),
    loadPomodoroState(),
    chrome.storage.local.get(STATE_KEY)
  ]);
  const state = stored[STATE_KEY] || await refreshRules();

  return {
    pomodoro,
    schedule: normalizeScheduleForStorage(schedule),
    settings,
    state
  };
}

async function saveSchedule(schedule) {
  const normalized = normalizeScheduleForStorage(schedule);
  await chrome.storage.local.set({ [SCHEDULE_KEY]: normalized });
  return normalized;
}

async function loadSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  return normalizeSettingsForStorage(stored[SETTINGS_KEY]);
}

async function loadPublicSettings() {
  const settings = await loadSettings();
  return publicSettings(settings);
}

async function saveSettings(value = {}) {
  const current = await loadSettings();
  let pinHash = current.pinHash;
  let pinValue = current.pinValue;

  if (value.clearPin) {
    pinHash = "";
    pinValue = "";
  } else if (value.pin) {
    const pin = String(value.pin);

    if (!/^\d{4}$/.test(pin)) {
      throw new Error("Use exactly 4 digits for the PIN.");
    }

    pinHash = await hashPin(pin);
    pinValue = pin;
  }

  const hasOwn = (key) => Object.prototype.hasOwnProperty.call(value, key);
  const requirePinForAllExtraTime = (hasOwn("requirePinForAllExtraTime")
    ? Boolean(value.requirePinForAllExtraTime)
    : Boolean(current.requirePinForAllExtraTime)) && Boolean(pinHash);
  const allowExtraTimeForAll = hasOwn("allowExtraTimeForAll")
    ? Boolean(value.allowExtraTimeForAll)
    : Boolean(current.allowExtraTimeForAll);
  const next = normalizeSettingsForStorage({
    pinHash,
    pinValue,
    requirePinForAllExtraTime,
    allowExtraTimeForAll
  });

  await chrome.storage.local.set({ [SETTINGS_KEY]: next });
  return publicSettings(next);
}

async function loadPomodoroState() {
  const stored = await chrome.storage.local.get(POMODORO_KEY);
  const pomodoro = normalizePomodoroState(stored[POMODORO_KEY]);

  if (stored[POMODORO_KEY]?.active && !pomodoro.active) {
    await appendPomodoroHistory(normalizePomodoroHistorySource(stored[POMODORO_KEY]), { completed: true });
    await savePomodoroState(pomodoro);
    await chrome.alarms.clear(POMODORO_ALARM);
  }

  return pomodoro;
}

async function getPomodoroStateForResponse() {
  const stored = await chrome.storage.local.get(POMODORO_KEY);
  const wasActive = Boolean(stored[POMODORO_KEY]?.active);
  const pomodoro = await loadPomodoroState();

  if (wasActive && !pomodoro.active) {
    try {
      await refreshRules();
    } catch (_error) {
    }
  }

  return pomodoro;
}

async function savePomodoroState(value = {}) {
  const pomodoro = normalizePomodoroState(value);
  await chrome.storage.local.set({ [POMODORO_KEY]: pomodoro });
  return pomodoro;
}

async function restorePomodoroAlarm() {
  const pomodoro = await loadPomodoroState();

  await chrome.alarms.clear(POMODORO_ALARM);

  if (pomodoro.active) {
    await chrome.alarms.create(POMODORO_ALARM, { when: pomodoro.until });
  }
}

async function startPomodoro({ duration = 30, mode = "standard", whitelist = [] } = {}) {
  const durationInMinutes = Math.max(1, Math.min(120, Math.round(Number(duration) || 30)));
  const startedAt = Date.now();
  const until = startedAt + durationInMinutes * 60 * 1000;
  const pomodoro = await savePomodoroState({
    active: true,
    startedAt,
    until,
    durationMinutes: durationInMinutes,
    mode,
    whitelist
  });

  await chrome.alarms.clear(POMODORO_ALARM);
  await chrome.alarms.create(POMODORO_ALARM, { when: pomodoro.until });

  let state = createPomodoroFallbackState(pomodoro);

  try {
    state = await refreshRules();
    await enforceActiveTabBlock(state);
  } catch (error) {
    state = {
      ...state,
      error: serializeError(error),
      lastUpdated: Date.now()
    };
    await saveState(state);
  }

  return { pomodoro, state };
}

async function stopPomodoro({ completed = false } = {}) {
  const stored = await chrome.storage.local.get(POMODORO_KEY);
  const previousPomodoro = normalizePomodoroHistorySource(stored[POMODORO_KEY]);

  await chrome.alarms.clear(POMODORO_ALARM);

  if (previousPomodoro.active) {
    await appendPomodoroHistory(previousPomodoro, { completed });
  }

  const pomodoro = await savePomodoroState();
  let state = createPomodoroFallbackState(pomodoro);

  try {
    state = await refreshRules();
  } catch (error) {
    state = {
      ...state,
      error: serializeError(error),
      lastUpdated: Date.now()
    };
    await saveState(state);
  }

  try {
    await enforceActiveTabBlock(state);
  } catch (_error) {
  }

  return { pomodoro, state };
}

function normalizePomodoroHistorySource(value = {}) {
  const until = normalizeTimestamp(value?.until);
  const durationMinutes = Math.max(1, Math.min(120, Math.round(Number(value?.durationMinutes) || 0)));
  const startedAt = normalizeTimestamp(value?.startedAt) || Math.max(0, until - durationMinutes * 60 * 1000);
  const active = Boolean(value?.active) && until > 0 && startedAt > 0;

  return {
    active,
    startedAt,
    until,
    durationMinutes,
    mode: value?.mode === "strict" ? "strict" : "standard",
    whitelist: normalizeWhitelist(value?.whitelist)
  };
}

async function appendPomodoroHistory(source, { completed = false } = {}) {
  if (!source?.active || !source.startedAt || !source.until) {
    return;
  }

  const now = Date.now();
  const endedAt = completed ? source.until : Math.min(now, source.until);
  const elapsedSeconds = Math.max(0, Math.round((endedAt - source.startedAt) / 1000));

  if (elapsedSeconds < 1) {
    return;
  }

  const plannedSeconds = Math.max(60, Math.round(source.durationMinutes * 60));
  const wasCompleted = Boolean(completed || elapsedSeconds >= plannedSeconds - 2);
  const entry = normalizePomodoroHistoryEntry({
    id: `${source.startedAt}-${source.until}-${source.mode}`,
    date: dateKeyFromTimestamp(source.startedAt),
    startedAt: source.startedAt,
    endedAt,
    plannedSeconds,
    elapsedSeconds: Math.min(elapsedSeconds, plannedSeconds),
    completed: wasCompleted,
    mode: source.mode,
    whitelistCount: source.whitelist.length
  });

  const stored = await chrome.storage.local.get(POMODORO_HISTORY_KEY);
  const history = normalizePomodoroHistory(stored[POMODORO_HISTORY_KEY]);
  const withoutDuplicate = history.filter((item) => item.id !== entry.id);

  await chrome.storage.local.set({
    [POMODORO_HISTORY_KEY]: prunePomodoroHistory([entry, ...withoutDuplicate])
  });
}

async function getPomodoroStats(date = "") {
  const selectedDate = /^\d{4}-\d{2}-\d{2}$/.test(String(date || "")) ? String(date) : getDateKey();
  const stored = await chrome.storage.local.get(POMODORO_HISTORY_KEY);
  const history = normalizePomodoroHistory(stored[POMODORO_HISTORY_KEY]);
  const selectedSessions = history
    .filter((entry) => entry.date === selectedDate)
    .sort((a, b) => b.startedAt - a.startedAt);

  const last7Days = Array.from({ length: 7 }, (_item, index) => {
    const dateObject = new Date();
    dateObject.setDate(dateObject.getDate() - (6 - index));
    const day = dateKeyFromDate(dateObject);
    const sessions = history.filter((entry) => entry.date === day);
    const totalSeconds = sessions.reduce((sum, entry) => sum + entry.elapsedSeconds, 0);
    const longestSessionSeconds = Math.max(0, ...sessions.map((entry) => entry.elapsedSeconds));

    return {
      date: day,
      totalSeconds,
      longestSessionSeconds,
      sessionCount: sessions.length,
      completedCount: sessions.filter((entry) => entry.completed).length
    };
  });

  const totalSeconds = selectedSessions.reduce((sum, entry) => sum + entry.elapsedSeconds, 0);
  const completedCount = selectedSessions.filter((entry) => entry.completed).length;
  const stoppedCount = selectedSessions.length - completedCount;

  return {
    date: selectedDate,
    selectedDay: {
      totalSeconds,
      sessionCount: selectedSessions.length,
      completedCount,
      stoppedCount,
      completionRate: selectedSessions.length > 0 ? Math.round((completedCount / selectedSessions.length) * 100) : 0,
      sessions: selectedSessions
    },
    today: {
      date: getDateKey(),
      totalSeconds: history
        .filter((entry) => entry.date === getDateKey())
        .reduce((sum, entry) => sum + entry.elapsedSeconds, 0)
    },
    last7Days,
    streakDays: getPomodoroStreakDays(history),
    totalSessions: history.length
  };
}

function normalizePomodoroHistory(value) {
  if (!Array.isArray(value)) {
    return [];
  }

  return value
    .map(normalizePomodoroHistoryEntry)
    .filter((entry) => entry.id && entry.startedAt > 0 && entry.endedAt >= entry.startedAt && entry.elapsedSeconds > 0)
    .sort((a, b) => b.startedAt - a.startedAt);
}

function normalizePomodoroHistoryEntry(value = {}) {
  const startedAt = normalizeTimestamp(value?.startedAt);
  const endedAt = normalizeTimestamp(value?.endedAt);
  const elapsedSeconds = Math.max(0, Math.round(Number(value?.elapsedSeconds) || 0));
  const plannedSeconds = Math.max(0, Math.round(Number(value?.plannedSeconds) || 0));

  return {
    id: typeof value?.id === "string" ? value.id : `${startedAt}-${endedAt}`,
    date: /^\d{4}-\d{2}-\d{2}$/.test(String(value?.date || "")) ? String(value.date) : dateKeyFromTimestamp(startedAt || Date.now()),
    startedAt,
    endedAt,
    plannedSeconds,
    elapsedSeconds,
    completed: Boolean(value?.completed),
    mode: value?.mode === "strict" ? "strict" : "standard",
    whitelistCount: Math.max(0, Math.round(Number(value?.whitelistCount) || 0))
  };
}

function prunePomodoroHistory(history) {
  const cutoff = Date.now() - MAX_POMODORO_HISTORY_DAYS * 24 * 60 * 60 * 1000;

  return normalizePomodoroHistory(history)
    .filter((entry) => entry.startedAt >= cutoff)
    .slice(0, MAX_POMODORO_HISTORY_ITEMS);
}

function getPomodoroStreakDays(history) {
  const activeDays = new Set(
    normalizePomodoroHistory(history)
      .filter((entry) => entry.elapsedSeconds > 0)
      .map((entry) => entry.date)
  );

  let streak = 0;
  const date = new Date();

  while (activeDays.has(dateKeyFromDate(date))) {
    streak += 1;
    date.setDate(date.getDate() - 1);
  }

  return streak;
}

function dateKeyFromTimestamp(timestamp) {
  return dateKeyFromDate(new Date(timestamp));
}

function dateKeyFromDate(date) {
  return [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0")
  ].join("-");
}

function createPomodoroFallbackState(pomodoro) {
  return {
    activeSites: [],
    error: "",
    lastUpdated: Date.now(),
    pomodoro: normalizePomodoroState(pomodoro),
    siteUsage: [],
    timezone: "local"
  };
}

function normalizePomodoroState(value = {}) {
  const until = normalizeTimestamp(value?.until);
  const active = Boolean(value?.active) && until > Date.now();
  const durationMinutes = Math.max(0, Math.min(120, Math.round(Number(value?.durationMinutes) || 0)));
  const startedAt = normalizeTimestamp(value?.startedAt);
  const fallbackStartedAt = active && durationMinutes > 0
    ? Math.max(0, until - durationMinutes * 60 * 1000)
    : 0;

  return {
    active,
    until: active ? until : 0,
    startedAt: active ? startedAt || fallbackStartedAt || Date.now() : 0,
    durationMinutes: active ? durationMinutes || Math.max(1, Math.round((until - (startedAt || Date.now())) / 60000)) : 0,
    mode: value?.mode === "strict" ? "strict" : "standard",
    whitelist: normalizeWhitelist(value?.whitelist)
  };
}

function normalizeWhitelist(value) {
  const items = Array.isArray(value)
    ? value
    : typeof value === "string"
      ? value.split(/[\s,]+/)
      : [];

  return Array.from(new Set(items.map((item) => normalizeDomain(item)).filter(Boolean)));
}

function normalizeSettingsForStorage(value = {}) {
  const pinHash = typeof value.pinHash === "string" ? value.pinHash : "";
  const pinValue = typeof value.pinValue === "string" ? String(value.pinValue).replace(/\D+/g, "").slice(0, 4) : "";

  return {
    pinHash,
    pinValue: pinHash ? pinValue : "",
    requirePinForAllExtraTime: Boolean(value.requirePinForAllExtraTime),
    allowExtraTimeForAll: Boolean(value.allowExtraTimeForAll)
  };
}

function publicSettings(settings) {
  return {
    hasPin: Boolean(settings.pinHash),
    requirePinForAllExtraTime: Boolean(settings.pinHash && settings.requirePinForAllExtraTime),
    allowExtraTimeForAll: Boolean(settings.allowExtraTimeForAll),
    pinValue: settings.pinHash ? settings.pinValue : ""
  };
}

async function hashPin(pin) {
  const shaHash = await createShaPinHash(pin);
  return shaHash || createFallbackPinHash(pin);
}

async function verifyPin(pin, settings) {
  const expectedHash = settings.pinHash;

  if (!expectedHash || !/^\d{4}$/.test(String(pin || ""))) {
    return false;
  }

  if (expectedHash.startsWith("fnv1a:")) {
    return createFallbackPinHash(pin) === expectedHash;
  }

  if (expectedHash.startsWith("sha256:")) {
    return await createShaPinHash(pin) === expectedHash;
  }

  return await createLegacyShaPinHash(pin) === expectedHash;
}

async function createShaPinHash(pin) {
  const hash = await createLegacyShaPinHash(pin);
  return hash ? `sha256:${hash}` : "";
}

async function createLegacyShaPinHash(pin) {
  if (!globalThis.crypto?.subtle) {
    return "";
  }

  try {
    const data = new TextEncoder().encode(`website-tracker:${pin}`);
    const digest = await globalThis.crypto.subtle.digest("SHA-256", data);
    return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
  } catch (_error) {
    return "";
  }
}

function createFallbackPinHash(pin) {
  const text = `website-tracker:${pin}`;
  let hash = 2166136261;

  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }

  return `fnv1a:${(hash >>> 0).toString(16).padStart(8, "0")}`;
}

function normalizeScheduleForStorage(schedule) {
  const rawSites = Array.isArray(schedule?.sites)
    ? schedule.sites
    : Array.isArray(schedule?.websites)
      ? schedule.websites
      : [];

  return {
    timezone: normalizeTimezone(schedule?.timezone),
    sites: rawSites
      .map((site) => normalizeSiteForStorage(site))
      .filter(Boolean)
  };
}

function normalizeTimezone(timezone) {
  if (typeof timezone !== "string") {
    return "local";
  }

  const value = timezone.trim();
  return value || "local";
}

function normalizeSiteForStorage(site) {
  const domainValues = pickDomainValues(site);
  const domains = domainValues
    .map((value) => normalizeDomain(value))
    .filter(Boolean);
  const uniqueDomains = Array.from(new Set(domains));

  if (uniqueDomains.length === 0) {
    return null;
  }

  return {
    domain: uniqueDomains[0],
    blockMode: normalizeBlockMode(site.blockMode, site.intervals),
    exceptions: normalizeExceptionDomains(site.exceptions ?? site.allowlist ?? site.allowList ?? site.allowedDomains, uniqueDomains),
    intervals: normalizeIntervalsForStorage(site.intervals),
    dailyAllowanceMinutes: normalizeDailyAllowance(site.dailyAllowanceMinutes ?? site.allowanceMinutes),
    allowExtraTime: Boolean(site.allowExtraTime),
    requirePinForExtraTime: Boolean(site.requirePinForExtraTime)
  };
}

function normalizeDailyAllowance(value) {
  const minutes = Number(value);

  if (!Number.isFinite(minutes) || minutes <= 0) {
    return 0;
  }

  return Math.min(Math.round(minutes), 24 * 60);
}

function normalizeIntervalsForStorage(intervals) {
  if (!Array.isArray(intervals)) {
    return [];
  }

  return intervals
    .map((interval) => normalizeIntervalForStorage(interval))
    .filter(Boolean);
}

function normalizeIntervalForStorage(interval) {
  const parsed = parseInterval(interval);

  if (!parsed) {
    return null;
  }

  const normalized = {
    start: minutesToClock(parsed.start),
    end: minutesToClock(parsed.end)
  };

  if (parsed.days) {
    const days = DAY_NAMES.filter((_name, index) => parsed.days.has(index));

    if (days.length > 0 && days.length < DAY_NAMES.length) {
      normalized.days = days;
    }
  }

  return normalized;
}

function minutesToClock(totalMinutes) {
  const minutes = Math.max(0, Math.min(24 * 60, totalMinutes));

  if (minutes === 24 * 60) {
    return "24:00";
  }

  const hours = Math.floor(minutes / 60);
  const remainder = minutes % 60;

  return `${String(hours).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`;
}

function getActiveSites(schedule, now, usage, settings = {}) {
  return getNormalizedScheduleSites(schedule)
    .filter((site) => shouldBlockSite(site, now, usage))
    .map((site) => toActiveSite(site, settings));
}

function getPomodoroStandardSites(schedule) {
  return getNormalizedScheduleSites(schedule).map((site) => toActiveSite({
    ...site,
    allowExtraTime: false
  }));
}

function getNormalizedScheduleSites(schedule) {
  const sites = Array.isArray(schedule.sites)
    ? schedule.sites
    : Array.isArray(schedule.websites)
      ? schedule.websites
      : [];

  return sites
    .map((site) => normalizeSite(site))
    .filter((site) => site.domains.length > 0);
}

function toActiveSite(site, settings = {}) {
  return {
    name: site.name,
    domain: site.domain,
    allowExtraTime: isExtraTimeAllowed(site, settings),
    domains: site.domains,
    exceptions: site.exceptions
  };
}

function normalizeSite(site) {
  const intervals = Array.isArray(site.intervals) ? site.intervals : [];
  const domainValues = pickDomainValues(site);
  const domains = domainValues
    .map((value) => normalizeDomain(value))
    .filter(Boolean);

  return {
    name: site.name || domains[0] || "Unnamed site",
    domain: domains[0] || "",
    domains: Array.from(new Set(domains)),
    blockMode: normalizeBlockMode(site.blockMode, intervals),
    exceptions: normalizeExceptionDomains(site.exceptions ?? site.allowlist ?? site.allowList ?? site.allowedDomains, domains),
    intervals,
    dailyAllowanceMinutes: normalizeDailyAllowance(site.dailyAllowanceMinutes ?? site.allowanceMinutes),
    allowExtraTime: Boolean(site.allowExtraTime),
    requirePinForExtraTime: Boolean(site.requirePinForExtraTime)
  };
}

function normalizeBlockMode(mode, intervals = []) {
  if (mode === "always" || mode === "slots") {
    return mode;
  }

  return isLegacyAllDayIntervals(intervals) ? "always" : "slots";
}

function pickDomainValues(site) {
  const value = site.domains ?? site.domain ?? site.match ?? site.url ?? site.website ?? site.websites;

  if (Array.isArray(value)) {
    return value;
  }

  if (typeof value === "string") {
    return [value];
  }

  return [];
}

function normalizeDomain(value) {
  if (typeof value !== "string") {
    return "";
  }

  let text = value.trim().toLowerCase();
  if (!text) {
    return "";
  }

  text = text
    .replace(/^\*:\/\/\*\./, "")
    .replace(/^\*:\/\/\*/, "")
    .replace(/^\*\./, "")
    .replace(/^www\./, "");

  try {
    const url = new URL(text.includes("://") ? text : `https://${text}`);
    return url.hostname.replace(/^www\./, "");
  } catch (_error) {
    return text.split("/")[0].replace(/^www\./, "");
  }
}

function normalizeExceptionDomains(value, baseDomains = []) {
  const values = Array.isArray(value)
    ? value
    : typeof value === "string"
      ? value.split(/[\s,]+/)
      : [];
  const normalizedBaseDomains = baseDomains
    .map((domain) => normalizeDomain(domain))
    .filter(Boolean);
  const domains = values
    .map((domain) => normalizeDomain(domain))
    .filter(Boolean)
    .filter((domain) => normalizedBaseDomains.length === 0 || normalizedBaseDomains.some((baseDomain) => {
      return domain !== baseDomain && domainMatches(domain, baseDomain);
    }));

  return Array.from(new Set(domains));
}

function getExceptionDomains(sites = []) {
  return Array.from(new Set(
    sites.flatMap((site) => Array.isArray(site.exceptions) ? site.exceptions : [])
      .map((domain) => normalizeDomain(domain))
      .filter(Boolean)
  ));
}

function hostMatchesException(host, exceptions = []) {
  const normalizedHost = normalizeDomain(host);

  return Boolean(normalizedHost && exceptions.some((domain) => domainMatches(normalizedHost, domain)));
}

function siteMatchesHost(site, host, { respectExceptions = true } = {}) {
  const normalizedHost = normalizeDomain(host);

  if (!normalizedHost) {
    return false;
  }

  if (!site.domains.some((domain) => domainMatches(normalizedHost, domain))) {
    return false;
  }

  return !respectExceptions || !hostMatchesException(normalizedHost, site.exceptions);
}

function shouldBlockSite(site, now, usage, host = "") {
  if (!isSiteInBlockedSlot(site, now)) {
    return false;
  }

  if (host && hostMatchesException(host, site.exceptions)) {
    return false;
  }

  if (hasTemporaryUnblock(site, usage)) {
    return false;
  }

  return getAllowanceRemainingSeconds(site, usage) <= 0;
}

function isSiteInBlockedSlot(site, now) {
  if (normalizeBlockMode(site.blockMode, site.intervals) === "always") {
    return true;
  }

  return site.intervals.some((interval) => isIntervalActive(interval, now));
}

function isIntervalActive(interval, now) {
  const parsed = parseInterval(interval);

  if (!parsed) {
    return false;
  }

  const { start, end, days } = parsed;

  if (start === end) {
    return dayMatches(days, now.day);
  }

  if (start < end) {
    return dayMatches(days, now.day) && now.minutes >= start && now.minutes < end;
  }

  const previousDay = (now.day + 6) % 7;
  return (
    (dayMatches(days, now.day) && now.minutes >= start) ||
    (dayMatches(days, previousDay) && now.minutes < end)
  );
}

function isLegacyAllDayIntervals(intervals) {
  const parsed = Array.isArray(intervals) && intervals.length === 1
    ? parseInterval(intervals[0])
    : null;

  return Boolean(parsed && parsed.start === parsed.end && (!parsed.days || parsed.days.size === DAY_NAMES.length));
}

function parseInterval(interval) {
  let start;
  let end;
  let days;

  if (typeof interval === "string") {
    const parts = interval.split("-");
    if (parts.length !== 2) {
      return null;
    }

    start = parts[0];
    end = parts[1];
  } else if (Array.isArray(interval)) {
    [start, end] = interval;
  } else if (interval && typeof interval === "object") {
    ({ start, end, days } = interval);
  } else {
    return null;
  }

  const startMinutes = parseClock(start);
  const endMinutes = parseClock(end);

  if (startMinutes === null || endMinutes === null) {
    return null;
  }

  return {
    start: startMinutes,
    end: endMinutes,
    days: normalizeDays(days)
  };
}

function parseClock(value) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value >= 0 && value <= 24 ? value * 60 : null;
  }

  if (typeof value !== "string") {
    return null;
  }

  const text = value.trim();
  const match = /^(\d{1,2})(?::([0-5]\d))?$/.exec(text);

  if (!match) {
    return null;
  }

  const hours = Number(match[1]);
  const minutes = Number(match[2] || "0");

  if (hours === 24 && minutes === 0) {
    return 24 * 60;
  }

  if (hours < 0 || hours > 23) {
    return null;
  }

  return hours * 60 + minutes;
}

function normalizeDays(days) {
  if (!days) {
    return null;
  }

  if (typeof days === "string") {
    const value = days.trim().toLowerCase();

    if (value === "weekday" || value === "weekdays") {
      return new Set([1, 2, 3, 4, 5]);
    }

    if (value === "weekend" || value === "weekends") {
      return new Set([0, 6]);
    }

    days = value.split(/[\s,]+/);
  }

  if (!Array.isArray(days)) {
    return null;
  }

  const normalized = days
    .map((day) => normalizeDay(day))
    .filter((day) => day !== null);

  return normalized.length > 0 ? new Set(normalized) : null;
}

function normalizeDay(day) {
  if (typeof day === "number" && Number.isInteger(day) && day >= 0 && day <= 6) {
    return day;
  }

  const value = String(day).trim().toLowerCase();
  return DAY_ALIASES.has(value) ? DAY_ALIASES.get(value) : null;
}

function dayMatches(days, day) {
  return !days || days.has(day);
}

async function accrueActiveUsage({ trackCurrent = true, requireCurrentMatch = true } = {}) {
  const [schedule, usage, trackingResult] = await Promise.all([
    loadSchedule(),
    getUsage(),
    chrome.storage.local.get(TRACKING_KEY)
  ]);
  const now = getTimeParts(schedule.timezone);
  const today = getDateKey();
  const currentTime = Date.now();
  const previous = trackingResult[TRACKING_KEY];
  let changedUsage = false;

  if (previous?.date === today && previous?.domain && Number.isFinite(previous.lastTick)) {
    const previousSite = findSiteForHost(schedule, previous.domain);

    if (
      previousSite &&
      isSiteInBlockedSlot(previousSite, now) &&
      (!requireCurrentMatch || await isTrackedSiteCurrentlyActive(previousSite, previous))
    ) {
      const entry = ensureUsageEntry(usage, previousSite.domain);
      const elapsedSeconds = getTrackableElapsedSeconds(previous.lastTick, currentTime);
      const extraConsumedSeconds = Math.min(elapsedSeconds, getExtraRemainingSeconds(entry));
      const allowanceRemainingSeconds = Math.max(
        0,
        getAllowanceRemainingSeconds(previousSite, usage) - extraConsumedSeconds
      );
      const allowanceConsumedSeconds = Math.min(
        Math.max(0, elapsedSeconds - extraConsumedSeconds),
        allowanceRemainingSeconds
      );
      const consumedSeconds = extraConsumedSeconds + allowanceConsumedSeconds;

      if (extraConsumedSeconds > 0) {
        entry.extraSeconds = Math.max(0, entry.extraSeconds - extraConsumedSeconds);

        if (entry.extraSeconds <= 0) {
          entry.extraUntil = 0;
        }
      }

      addUsedSeconds(usage, previousSite.domain, consumedSeconds);
      changedUsage = consumedSeconds > 0;
    }
  }

  if (changedUsage) {
    await saveUsage(usage);
  }

  if (!trackCurrent || extensionPopupOpenCount > 0) {
    await chrome.storage.local.remove(TRACKING_KEY);
    return;
  }

  const activeInfo = await getActiveTrackedInfo(schedule, now, usage);

  if (!activeInfo) {
    await chrome.storage.local.remove(TRACKING_KEY);
    return;
  }

  await chrome.storage.local.set({
    [TRACKING_KEY]: {
      domain: activeInfo.site.domain,
      lastTick: currentTime,
      date: today,
      tabId: activeInfo.tab.id
    }
  });
}

async function accrueScreenUsage() {
  const today = getDateKey();
  const [usage, trackingResult] = await Promise.all([
    getUsage(),
    chrome.storage.local.get(SCREEN_TRACKING_KEY)
  ]);
  const currentTime = Date.now();
  const previous = trackingResult[SCREEN_TRACKING_KEY];
  let changedUsage = false;

  if (previous?.date === today && previous?.domain && Number.isFinite(previous.lastTick)) {
    const elapsedSeconds = getTrackableElapsedSeconds(previous.lastTick, currentTime);

    changedUsage = addScreenUsageSeconds(
      usage,
      previous.domain,
      currentTime - elapsedSeconds * 1000,
      currentTime
    ) || changedUsage;
  }

  if (changedUsage) {
    await saveUsage(usage);
  }

  const tab = await getActiveHttpTab();
  const domain = tab ? getHostname(tab.url) : "";

  if (!domain) {
    await chrome.storage.local.remove(SCREEN_TRACKING_KEY);
    return;
  }

  await chrome.storage.local.set({
    [SCREEN_TRACKING_KEY]: {
      domain,
      lastTick: currentTime,
      date: today,
      tabId: tab.id
    }
  });
}

async function getActiveTrackedInfo(schedule, now, usage) {
  const tab = await getActiveHttpTab();

  if (!tab) {
    return null;
  }

  const host = getHostname(tab.url);
  const site = findSiteForHost(schedule, host);

  if (!site || !isSiteInBlockedSlot(site, now)) {
    return null;
  }

  if (!hasTemporaryUnblock(site, usage) && getAllowanceRemainingSeconds(site, usage) <= 0) {
    return null;
  }

  return { site, tab };
}

async function isTrackedSiteCurrentlyActive(site, tracking) {
  const tab = await getActiveHttpTab();

  if (!tab) {
    return false;
  }

  if (Number.isFinite(tracking?.tabId) && tab.id !== tracking.tabId) {
    return false;
  }

  const host = getHostname(tab.url);
  return siteMatchesHost(site, host);
}

async function enforceActiveTabBlock(state) {
  const tab = await getActiveHttpTab();

  if (!tab) {
    return;
  }

  const host = getHostname(tab.url);

  if (state.pomodoro?.active && state.pomodoro.mode === "strict") {
    if (!isStrictPomodoroAllowed(host, state.pomodoro)) {
      await chrome.tabs.update(tab.id, { url: getPomodoroBlockedPageUrl() });
    } else {
      await hideStatePreservingBlock(tab.id);
    }

    return;
  }

  const blockedSite = (state.activeSites || []).find((site) => {
    return (site.domains || []).some((domain) => domainMatches(host, domain)) &&
      !hostMatchesException(host, getExceptionDomains(state.activeSites || []));
  });

  if (!blockedSite) {
    await hideStatePreservingBlock(tab.id);
    return;
  }

  const blockedDomain = blockedSite.domain || blockedSite.domains?.[0] || host;
  const showedOverlay = await showStatePreservingBlock(tab.id, blockedDomain);

  if (!showedOverlay) {
    await chrome.tabs.update(tab.id, { url: getBlockedPageUrl(blockedDomain, tab.url) });
  }
}

async function showStatePreservingBlock(tabId, domain) {
  try {
    const status = await getSiteStatus(domain);

    await ensureStatePreservingContentScript(tabId);
    const response = await chrome.tabs.sendMessage(tabId, {
      type: "focus-tracker-show-state-blocker",
      status
    });

    return Boolean(response?.ok);
  } catch (_error) {
    return false;
  }
}

async function hideStatePreservingBlock(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "focus-tracker-hide-state-blocker" });
  } catch (_error) {
  }
}

async function ensureStatePreservingContentScript(tabId) {
  try {
    const response = await chrome.tabs.sendMessage(tabId, { type: "focus-tracker-ping-state-blocker" });

    if (response?.ok) {
      return;
    }
  } catch (_error) {
  }

  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["shared/block-panel-ui.js", "content/state-preserving-block.js"]
  });
}

async function getActiveHttpTab() {
  const focusedWindow = await chrome.windows.getLastFocused();

  if (!focusedWindow?.focused || typeof focusedWindow.id !== "number") {
    return null;
  }

  const [tab] = await chrome.tabs.query({ active: true, windowId: focusedWindow.id });

  if (typeof tab?.id !== "number" || !/^https?:\/\//.test(tab.url || "")) {
    return null;
  }

  return tab;
}

function findSiteForHost(schedule, host) {
  if (!host) {
    return null;
  }

  const sites = Array.isArray(schedule.sites) ? schedule.sites : [];

  return sites
    .map((site) => normalizeSite(site))
    .find((site) => siteMatchesHost(site, host)) || null;
}

function domainMatches(host, domain) {
  return host === domain || host.endsWith(`.${domain}`);
}

function getHostname(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "").toLowerCase();
  } catch (_error) {
    return "";
  }
}

async function getSiteStatus(domain) {
  const normalizedDomain = normalizeDomain(domain);
  const [schedule, usage, settings, pomodoro] = await Promise.all([loadSchedule(), getUsage(), loadSettings(), loadPomodoroState()]);
  const now = getTimeParts(schedule.timezone);
  const site = findSiteForHost(schedule, normalizedDomain);

  if (!site) {
    return {
      found: false,
      domain: normalizedDomain,
      pomodoro
    };
  }

  return buildSiteUsageState(site, now, usage, settings, pomodoro);
}

async function addExtraTime(domain, minutes, pin = "", tabId = null) {
  const normalizedDomain = normalizeDomain(domain);
  const [schedule, usage, settings, pomodoro] = await Promise.all([loadSchedule(), getUsage(), loadSettings(), loadPomodoroState()]);
  const site = findSiteForHost(schedule, normalizedDomain);

  if (pomodoro.active) {
    throw new Error("Focus session active.");
  }

  if (!site) {
    throw new Error("This website is not in the schedule.");
  }

  if (!isExtraTimeAllowed(site, settings)) {
    throw new Error("Extra time is disabled for this website.");
  }

  if (isExtraTimePinRequired(site, settings)) {
    if (!String(pin || "").trim()) {
      throw new Error("PIN required.");
    }

    if (!await verifyPin(pin, settings)) {
      throw new Error("PIN verification failed.");
    }
  }

  const extraMinutes = Number(minutes);

  if (!Number.isFinite(extraMinutes) || extraMinutes <= 0) {
    throw new Error("Choose how many minutes to add.");
  }

  grantExtraTime(usage, site, Math.min(Math.round(extraMinutes), 240) * 60);
  await saveUsage(usage);
  await startActiveUsageTracking(site, tabId);
}

async function cutOffSite(domain) {
  const normalizedDomain = normalizeDomain(domain);
  const [schedule, usage] = await Promise.all([loadSchedule(), getUsage()]);
  const site = findSiteForHost(schedule, normalizedDomain);

  if (!site) {
    return;
  }

  resetExtraTimeState(usage, site);
  await saveUsage(usage);
  await chrome.storage.local.remove(TRACKING_KEY);
}

async function getUsage() {
  const today = getDateKey();
  const stored = await chrome.storage.local.get([USAGE_KEY, USAGE_HISTORY_KEY]);
  const usage = normalizeUsageSnapshot(stored[USAGE_KEY], today);

  if (usage.date === today) {
    return usage;
  }

  const history = normalizeUsageHistory(stored[USAGE_HISTORY_KEY]);

  if (Object.keys(usage.sites).length > 0) {
    history[usage.date] = usage;
  }

  await chrome.storage.local.set({
    [USAGE_KEY]: {
      date: today,
      sites: {}
    },
    [USAGE_HISTORY_KEY]: pruneUsageHistory(history)
  });

  return {
    date: today,
    sites: {}
  };
}

async function getUsageData() {
  const usage = await getUsage();
  const stored = await chrome.storage.local.get(USAGE_HISTORY_KEY);
  const history = normalizeUsageHistory(stored[USAGE_HISTORY_KEY]);
  const usageByDay = {
    ...history,
    [usage.date]: usage
  };

  return {
    days: Object.keys(usageByDay).sort().reverse(),
    usageByDay
  };
}

async function saveUsage(usage) {
  await chrome.storage.local.set({ [USAGE_KEY]: normalizeUsageSnapshot(usage, getDateKey()) });
}

function getDateKey() {
  const now = new Date();
  return [
    now.getFullYear(),
    String(now.getMonth() + 1).padStart(2, "0"),
    String(now.getDate()).padStart(2, "0")
  ].join("-");
}

function ensureUsageEntry(usage, domain) {
  const normalizedDomain = normalizeDomain(domain);

  if (!normalizedDomain) {
    return normalizeUsageEntry();
  }

  usage.sites ||= {};
  usage.sites[normalizedDomain] = normalizeUsageEntry(usage.sites[normalizedDomain]);
  return usage.sites[normalizedDomain];
}

function addUsedSeconds(usage, domain, seconds) {
  if (seconds <= 0) {
    return;
  }

  const entry = ensureUsageEntry(usage, domain);
  entry.usedSeconds += seconds;
}

async function startActiveUsageTracking(site, tabId = null) {
  const tracking = {
    domain: site.domain,
    lastTick: Date.now(),
    date: getDateKey()
  };

  if (Number.isFinite(tabId)) {
    tracking.tabId = tabId;
  }

  await chrome.storage.local.set({ [TRACKING_KEY]: tracking });
}

function resetExtraTimeState(usage, site) {
  const entry = ensureUsageEntry(usage, site.domain);

  entry.extraSeconds = 0;
  entry.extraUntil = 0;
  entry.usedSeconds = Math.max(0, entry.usedSeconds);
}

function grantExtraTime(usage, site, seconds) {
  const addedSeconds = Math.max(0, Number(seconds) || 0);

  if (addedSeconds <= 0) {
    return;
  }

  const entry = ensureUsageEntry(usage, site.domain);
  const allowanceSeconds = normalizeDailyAllowance(site.dailyAllowanceMinutes) * 60;

  entry.usedSeconds = Math.max(entry.usedSeconds, allowanceSeconds);
  entry.extraSeconds = addedSeconds;
  entry.extraUntil = 0;
}

function getTrackableElapsedSeconds(startTime, endTime) {
  const elapsedSeconds = Math.max(0, (Number(endTime) - Number(startTime)) / 1000);

  if (!Number.isFinite(elapsedSeconds) || elapsedSeconds <= 0) {
    return 0;
  }

  if (elapsedSeconds > MAX_TRACKING_GAP_SECONDS) {
    return 0;
  }

  return elapsedSeconds;
}

function addScreenUsageSeconds(usage, domain, startTime, endTime) {
  const start = Number(startTime);
  const end = Number(endTime);

  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) {
    return false;
  }

  const entry = ensureUsageEntry(usage, domain);
  let cursor = start;

  while (cursor < end) {
    const cursorDate = new Date(cursor);
    const hour = cursorDate.getHours();
    const nextHour = new Date(cursorDate);
    nextHour.setHours(hour + 1, 0, 0, 0);

    const segmentEnd = Math.min(end, nextHour.getTime());
    const seconds = Math.max(0, (segmentEnd - cursor) / 1000);
    entry.screenSeconds += seconds;
    entry.hourlySeconds[hour] += seconds;
    cursor = segmentEnd;
  }

  return true;
}

function getSiteUsageEntry(usage, domain) {
  const normalizedDomain = normalizeDomain(domain);
  const entry = normalizedDomain ? usage.sites?.[normalizedDomain] : {};

  return {
    usedSeconds: Math.max(0, Number(entry?.usedSeconds) || 0),
    extraSeconds: Math.max(0, Number(entry?.extraSeconds) || 0),
    extraUntil: normalizeTimestamp(entry?.extraUntil),
    screenSeconds: Math.max(0, Number(entry?.screenSeconds) || 0),
    hourlySeconds: normalizeHourlySeconds(entry?.hourlySeconds)
  };
}

function normalizeUsageSnapshot(value, fallbackDate = getDateKey()) {
  const date = typeof value?.date === "string" && value.date
    ? value.date
    : fallbackDate;
  const sites = {};

  if (value?.sites && typeof value.sites === "object") {
    Object.entries(value.sites).forEach(([domain, entry]) => {
      const normalizedDomain = normalizeDomain(domain);

      if (normalizedDomain) {
        sites[normalizedDomain] = normalizeUsageEntry(entry);
      }
    });
  }

  return { date, sites };
}

function normalizeUsageEntry(entry = {}) {
  return {
    usedSeconds: Math.max(0, Number(entry.usedSeconds) || 0),
    extraSeconds: Math.max(0, Number(entry.extraSeconds) || 0),
    extraUntil: normalizeTimestamp(entry.extraUntil),
    screenSeconds: Math.max(0, Number(entry.screenSeconds) || 0),
    hourlySeconds: normalizeHourlySeconds(entry.hourlySeconds)
  };
}

function normalizeTimestamp(value) {
  const timestamp = Number(value);

  return Number.isFinite(timestamp) && timestamp > 0 ? timestamp : 0;
}

function normalizeHourlySeconds(value) {
  return Array.from({ length: 24 }, (_unused, index) => {
    return Math.max(0, Number(Array.isArray(value) ? value[index] : 0) || 0);
  });
}

function normalizeUsageHistory(value) {
  const history = {};

  if (!value || typeof value !== "object") {
    return history;
  }

  Object.entries(value).forEach(([date, snapshot]) => {
    if (/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      history[date] = normalizeUsageSnapshot(snapshot, date);
    }
  });

  return history;
}

function pruneUsageHistory(history) {
  return Object.fromEntries(
    Object.entries(history)
      .sort(([left], [right]) => right.localeCompare(left))
      .slice(0, MAX_USAGE_HISTORY_DAYS)
  );
}

function getRemainingSeconds(site, usage, now = Date.now()) {
  const extraRemaining = getExtraRemainingSeconds(getSiteUsageEntry(usage, site.domain), now);

  if (extraRemaining > 0) {
    return extraRemaining;
  }

  return getAllowanceRemainingSeconds(site, usage);
}

function getAllowanceRemainingSeconds(site, usage) {
  const entry = getSiteUsageEntry(usage, site.domain);
  const allowanceSeconds = site.dailyAllowanceMinutes * 60;

  return Math.max(0, allowanceSeconds - entry.usedSeconds);
}

function hasTemporaryUnblock(site, usage, now = Date.now()) {
  return getExtraRemainingSeconds(getSiteUsageEntry(usage, site.domain), now) > 0;
}

function getExtraRemainingSeconds(entry, _now = Date.now()) {
  return Math.max(0, Number(entry?.extraSeconds) || 0);
}

function getSiteUsageStates(schedule, now, usage, settings, pomodoro = normalizePomodoroState()) {
  const sites = Array.isArray(schedule.sites) ? schedule.sites : [];

  return sites
    .map((site) => normalizeSite(site))
    .filter((site) => site.domain)
    .map((site) => buildSiteUsageState(site, now, usage, settings, pomodoro));
}

function buildSiteUsageState(site, now, usage, settings = {}, pomodoro = normalizePomodoroState()) {
  const entry = getSiteUsageEntry(usage, site.domain);
  const currentTime = Date.now();
  const pomodoroBlocking = isPomodoroBlockingSite(site, pomodoro);

  return {
    found: true,
    domain: site.domain,
    allowExtraTime: pomodoroBlocking ? false : isExtraTimeAllowed(site, settings),
    dailyAllowanceMinutes: site.dailyAllowanceMinutes,
    exceptions: site.exceptions,
    extraSeconds: entry.extraSeconds,
    extraUntil: entry.extraUntil,
    extraRemainingSeconds: getExtraRemainingSeconds(entry, currentTime),
    inBlockedSlot: pomodoroBlocking || isSiteInBlockedSlot(site, now),
    isBlocked: pomodoroBlocking || shouldBlockSite(site, now, usage),
    pinConfigured: Boolean(settings.pinHash),
    pomodoro,
    remainingSeconds: pomodoroBlocking ? 0 : getRemainingSeconds(site, usage, currentTime),
    requiresPinForExtraTime: !pomodoroBlocking && isExtraTimePinRequired(site, settings),
    usedSeconds: entry.usedSeconds
  };
}

function isPomodoroBlockingSite(site, pomodoro = normalizePomodoroState()) {
  return Boolean(pomodoro.active && pomodoro.mode === "standard" && site.domain);
}

function isExtraTimePinRequired(site, settings = {}) {
  return Boolean(settings.pinHash && (settings.requirePinForAllExtraTime || site.requirePinForExtraTime));
}

function isExtraTimeAllowed(site, settings = {}) {
  return Boolean(settings.allowExtraTimeForAll || site.allowExtraTime);
}

function getTimeParts(timezone = "local") {
  if (!timezone || timezone === "local") {
    const now = new Date();
    return {
      day: now.getDay(),
      minutes: now.getHours() * 60 + now.getMinutes()
    };
  }

  try {
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone: timezone,
      weekday: "short",
      hour: "2-digit",
      minute: "2-digit",
      hourCycle: "h23"
    }).formatToParts(new Date());
    const weekday = parts.find((part) => part.type === "weekday")?.value.toLowerCase();
    const hour = Number(parts.find((part) => part.type === "hour")?.value);
    const minute = Number(parts.find((part) => part.type === "minute")?.value);

    return {
      day: DAY_ALIASES.get(weekday) ?? new Date().getDay(),
      minutes: hour * 60 + minute
    };
  } catch {
    return getTimeParts("local");
  }
}

function createRedirectRule(id, site, exceptionDomains = []) {
  const condition = {
    requestDomains: site.domains,
    resourceTypes: ["main_frame"]
  };
  const excludedRequestDomains = getExceptionDomains([
    { exceptions: exceptionDomains },
    site
  ]);

  if (excludedRequestDomains.length > 0) {
    condition.excludedRequestDomains = excludedRequestDomains;
  }

  return {
    id,
    priority: 1,
    action: {
      type: "redirect",
      redirect: {
        url: getBlockedPageUrl(site.domain || site.domains[0])
      }
    },
    condition
  };
}

function createStrictPomodoroRule(pomodoro) {
  const excludedRequestDomains = getStrictPomodoroExcludedDomains(pomodoro);
  const condition = {
    regexFilter: "^https?://",
    resourceTypes: ["main_frame"]
  };

  if (excludedRequestDomains.length > 0) {
    condition.excludedRequestDomains = excludedRequestDomains;
  }

  return {
    id: 1,
    priority: 1,
    action: {
      type: "redirect",
      redirect: {
        url: getPomodoroBlockedPageUrl()
      }
    },
    condition
  };
}

function getStrictPomodoroExcludedDomains(pomodoro) {
  return Array.from(new Set([
    ...normalizeWhitelist(pomodoro?.whitelist),
    chrome.runtime.id
  ].filter(Boolean)));
}

function isStrictPomodoroAllowed(host, pomodoro) {
  const normalizedHost = normalizeDomain(host);
  return normalizeWhitelist(pomodoro?.whitelist).some((domain) => domainMatches(normalizedHost, domain));
}

function getBlockedPageUrl(domain, targetUrl = "") {
  const params = new URLSearchParams({ site: domain || "" });
  const target = normalizeHttpUrl(targetUrl);

  if (target) {
    params.set("target", target);
  }

  return chrome.runtime.getURL(`${BLOCKED_PAGE.slice(1)}?${params.toString()}`);
}

function getPomodoroBlockedPageUrl() {
  return chrome.runtime.getURL(`${BLOCKED_PAGE.slice(1)}?pomodoro=1`);
}

function getResumeTargetUrl(targetUrl, fallbackDomain) {
  const directUrl = normalizeHttpUrl(targetUrl);

  if (directUrl) {
    return directUrl;
  }

  const normalizedDomain = normalizeDomain(fallbackDomain);
  return normalizedDomain ? `https://${normalizedDomain}/` : "";
}

function normalizeHttpUrl(value) {
  if (typeof value !== "string") {
    return "";
  }

  const text = value.trim();

  if (!/^https?:\/\//i.test(text)) {
    return "";
  }

  try {
    return new URL(text).toString();
  } catch (_error) {
    return "";
  }
}

async function replaceDynamicRules(rules) {
  const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existingRules.map((rule) => rule.id);

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds,
    addRules: rules
  });
}

async function saveState(state) {
  await chrome.storage.local.set({ [STATE_KEY]: state });
}

async function updateBadge(activeCount, hasError = false) {
  const text = hasError ? "!" : typeof activeCount === "string" ? activeCount : activeCount > 0 ? String(activeCount) : "";
  const color = hasError ? "#b42318" : "#2563eb";

  await chrome.action.setBadgeText({ text });
  await chrome.action.setBadgeBackgroundColor({ color });
}

function serializeError(error) {
  if (error && typeof error === "object" && "message" in error) {
    return String(error.message || "Something went wrong.").replace(/^Error:\s*/, "");
  }

  return String(error || "Something went wrong.").replace(/^Error:\s*/, "");
}
