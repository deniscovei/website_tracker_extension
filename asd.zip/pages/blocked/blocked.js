const params = new URLSearchParams(window.location.search);
const site = params.get("site") || "";
const extraTime = document.getElementById("extra-time");
const popupViewRoot = document.getElementById("popup-view-root");
const blockedTitle = document.getElementById("blocked-title");
const blockedMessage = document.getElementById("blocked-message");
const pomodoroBlock = document.getElementById("pomodoro-block");
const blockedPomodoroTimer = document.getElementById("blocked-pomodoro-timer");
const blockedPomodoroMode = document.getElementById("blocked-pomodoro-mode");
const isPomodoroOnlyPage = params.get("pomodoro") === "1";

const VIEW_STATE = {
  SELECT: "select",
  SUCCESS: "success",
  PIN: "pin"
};
const FINAL_ACTION_LABEL = "Enter Page";

let latestStatus = null;
let currentView = VIEW_STATE.SELECT;
let pendingMinutes = 0;
let actionInFlight = false;
let pinDraft = "";
let pinError = "";
let pomodoroTickTimer = 0;
let pomodoroStateCheckTicks = 0;
let pomodoroStateCheckInFlight = false;

void loadExtraTimeStatus();

window.addEventListener("beforeunload", clearPomodoroTimer);

async function loadExtraTimeStatus() {
  const pomodoro = await loadPomodoroState();

  if (pomodoro.active) {
    renderPomodoroBlock(pomodoro);
    return;
  }

  clearPomodoroTimer();

  if (pomodoroBlock) {
    pomodoroBlock.hidden = true;
  }

  if (isPomodoroOnlyPage) {
    renderPomodoroEnded();
    return;
  }

  if (!site) {
    return;
  }

  try {
    const response = await chrome.runtime.sendMessage({
      type: "get-site-status",
      domain: site
    });

    if (response?.status?.pomodoro?.active) {
      renderPomodoroBlock(response.status.pomodoro);
      return;
    }

    if (!response?.ok || !response.status?.found) {
      extraTime.hidden = true;
      return;
    }

    latestStatus = response.status;

    if (!latestStatus.isBlocked) {
      navigateToSite();
      return;
    }

    if (!latestStatus.allowExtraTime) {
      extraTime.hidden = true;
      return;
    }

    currentView = VIEW_STATE.SELECT;
    pendingMinutes = 0;
    actionInFlight = false;
    pinDraft = "";
    pinError = "";
    extraTime.hidden = false;
    renderCurrentView();
  } catch {
    extraTime.hidden = true;
  }
}

async function loadPomodoroState() {
  try {
    const response = await chrome.runtime.sendMessage({ type: "get-pomodoro-state" });

    if (response?.ok) {
      return normalizePomodoro(response.pomodoro);
    }
  } catch (_error) {
    return normalizePomodoro();
  }

  return normalizePomodoro();
}

function renderPomodoroBlock(pomodoro) {
  const activePomodoro = normalizePomodoro(pomodoro);

  if (!activePomodoro.active) {
    renderPomodoroEnded();
    return;
  }

  clearPomodoroTimer();

  if (blockedTitle) {
    blockedTitle.textContent = "Focus Session Active";
  }

  if (blockedMessage) {
    blockedMessage.textContent = activePomodoro.mode === "strict"
      ? "Strict Mode is blocking the internet except your whitelist."
      : "Standard Mode is keeping websites blocked until the focus session ends.";
  }

  if (extraTime) {
    extraTime.hidden = true;
  }

  if (pomodoroBlock) {
    pomodoroBlock.hidden = false;
  }

  if (blockedPomodoroMode) {
    blockedPomodoroMode.textContent = activePomodoro.mode === "strict"
      ? getStrictModeLabel(activePomodoro)
      : "Standard Focus Mode";
  }

  updatePomodoroTimer(activePomodoro);
  pomodoroStateCheckTicks = 0;

  pomodoroTickTimer = window.setInterval(() => {
    const stillActive = updatePomodoroTimer(activePomodoro);

    if (!stillActive) {
      void syncPomodoroBlockState(activePomodoro).catch(() => {
        renderPomodoroEnded();
      });
      return;
    }

    pomodoroStateCheckTicks += 1;

    if (pomodoroStateCheckTicks >= 2) {
      pomodoroStateCheckTicks = 0;
      void syncPomodoroBlockState(activePomodoro);
    }
  }, 1000);
}

async function syncPomodoroBlockState(renderedPomodoro) {
  if (pomodoroStateCheckInFlight) {
    return;
  }

  pomodoroStateCheckInFlight = true;

  try {
    const latestPomodoro = await loadPomodoroState();

    if (!latestPomodoro.active && !isPomodoroOnlyPage && site) {
      await loadExtraTimeStatus();
      return;
    }

    if (!latestPomodoro.active) {
      renderPomodoroEnded();
      return;
    }

    if (latestPomodoro.until !== renderedPomodoro.until || latestPomodoro.mode !== renderedPomodoro.mode) {
      renderPomodoroBlock(latestPomodoro);
    }
  } finally {
    pomodoroStateCheckInFlight = false;
  }
}

function updatePomodoroTimer(pomodoro) {
  const remainingSeconds = Math.max(0, Math.ceil((pomodoro.until - Date.now()) / 1000));

  if (blockedPomodoroTimer) {
    blockedPomodoroTimer.textContent = formatPomodoroTime(remainingSeconds);
  }

  return remainingSeconds > 0;
}

function renderPomodoroEnded() {
  clearPomodoroTimer();

  if (blockedTitle) {
    blockedTitle.textContent = "Focus session ended";
  }

  if (blockedMessage) {
    blockedMessage.textContent = "Reload the page or return to your tab to continue.";
  }

  if (pomodoroBlock) {
    pomodoroBlock.hidden = true;
  }

  if (extraTime) {
    extraTime.hidden = true;
  }
}

function clearPomodoroTimer() {
  if (pomodoroTickTimer) {
    window.clearInterval(pomodoroTickTimer);
    pomodoroTickTimer = 0;
  }

  pomodoroStateCheckTicks = 0;
}

function formatPomodoroTime(totalSeconds) {
  const seconds = Math.max(0, Math.floor(Number(totalSeconds) || 0));
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainder = seconds % 60;

  if (hours > 0) {
    return `${hours}:${String(minutes).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`;
  }

  return `${String(minutes).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`;
}

function getStrictModeLabel(pomodoro) {
  const whitelistCount = Array.isArray(pomodoro.whitelist) ? pomodoro.whitelist.length : 0;

  if (whitelistCount === 0) {
    return "Strict Focus Mode";
  }

  return `Strict Focus Mode · ${whitelistCount} allowed`;
}

function renderCurrentView() {
  syncBlockedHeader();
  popupViewRoot.replaceChildren();

  if (currentView === VIEW_STATE.SUCCESS) {
    popupViewRoot.append(createSuccessView());
  } else if (currentView === VIEW_STATE.PIN) {
    popupViewRoot.append(createPinView());
    requestAnimationFrame(() => {
      popupViewRoot.querySelector("#pin-code")?.focus();
    });
  } else {
    popupViewRoot.append(createSelectionView());
  }
}

function syncBlockedHeader() {
  if (blockedTitle) {
    blockedTitle.textContent = "This website is blocked";
  }

  if (blockedMessage) {
    blockedMessage.textContent = latestStatus?.allowExtraTime
      ? "Your time is up for this website. Add more time to continue where you left off."
      : "Your time is up for this website.";
  }
}

function createSelectionView() {
  const view = document.createElement("section");
  const ui = globalThis.FocusTrackerBlockPanel;

  view.className = "popup-view popup-view-selection";
  view.innerHTML = ui.renderMinuteButtons({
    minutes: [5, 15, 30],
    disabled: actionInFlight
  });

  view.querySelectorAll("[data-minutes]").forEach((button) => {
    button.addEventListener("click", () => {
      const minutes = Number(button.getAttribute("data-minutes"));
      void handleMinuteSelection(minutes);
    });
  });

  return view;
}

function createSuccessView() {
  const view = document.createElement("section");
  const message = document.createElement("p");
  const ui = globalThis.FocusTrackerBlockPanel;

  view.className = "popup-view popup-view-success";
  message.className = "ft-block-confirm-message";
  message.textContent = `Add ${formatMinutes(pendingMinutes)} and enter the page.`;

  view.innerHTML = ui.renderActionButtons({
    primaryText: FINAL_ACTION_LABEL,
    secondaryText: "Back",
    disabled: actionInFlight
  });
  view.prepend(message);

  view.querySelector("[data-secondary-action]")?.addEventListener("click", () => {
    returnToSelection();
  });

  view.querySelector("[data-primary-action]")?.addEventListener("click", () => {
    void confirmStagedMinutes();
  });

  return view;
}

function createPinView() {
  const view = document.createElement("section");
  const ui = globalThis.FocusTrackerBlockPanel;

  view.className = "popup-view popup-view-pin";
  view.innerHTML = `
    <p class="ft-block-confirm-message">Add ${formatMinutes(pendingMinutes)} and enter the page.</p>
    ${ui.renderPinField({
      inputId: "pin-code",
      disabled: actionInFlight,
      value: pinDraft
    })}
    ${ui.renderError(pinError)}
    ${ui.renderActionButtons({
      primaryText: FINAL_ACTION_LABEL,
      secondaryText: "Back",
      disabled: actionInFlight
    })}
  `;

  const input = view.querySelector("#pin-code");
  const continueButton = view.querySelector("[data-primary-action]");
  const backButton = view.querySelector("[data-secondary-action]");

  if (input instanceof HTMLInputElement) {
    input.setAttribute("aria-label", "PIN");
    input.addEventListener("input", () => {
      input.value = sanitizePinValue(input.value);
      pinDraft = input.value;
      pinError = "";
      view.querySelector(".ft-block-error")?.remove();

      if (continueButton instanceof HTMLButtonElement) {
        continueButton.disabled = actionInFlight || input.value.length !== 4;
      }
    });
    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && continueButton instanceof HTMLButtonElement && !continueButton.disabled) {
        event.preventDefault();
        continueButton.click();
      }
    });
  }

  backButton?.addEventListener("click", () => {
    returnToSelection();
  });

  if (continueButton instanceof HTMLButtonElement) {
    continueButton.disabled = actionInFlight || pinDraft.length !== 4;
  }

  continueButton?.addEventListener("click", () => {
    void handlePinSubmit(input);
  });

  return view;
}

async function handleMinuteSelection(minutes) {
  pendingMinutes = Math.max(0, Number(minutes) || 0);

  if (pendingMinutes <= 0 || !site || actionInFlight) {
    return;
  }

  actionInFlight = true;
  pinError = "";
  renderCurrentView();

  let refreshedStatus = null;

  try {
    const response = await chrome.runtime.sendMessage({
      type: "get-site-status",
      domain: site
    });

    if (!response?.ok || !response.status?.found || !response.status.allowExtraTime) {
      extraTime.hidden = true;
    } else {
      refreshedStatus = response.status;
    }
  } catch {
  } finally {
    actionInFlight = false;
  }

  if (!refreshedStatus) {
    currentView = VIEW_STATE.SELECT;
    renderCurrentView();
    return;
  }

  latestStatus = refreshedStatus;

  if (!latestStatus.isBlocked) {
    navigateToSite();
    return;
  }

  if (latestStatus.requiresPinForExtraTime) {
    pinDraft = "";
    pinError = "";
    currentView = VIEW_STATE.PIN;
    renderCurrentView();
    return;
  }

  currentView = VIEW_STATE.SUCCESS;
  renderCurrentView();
}

async function handlePinSubmit(input) {
  const pin = sanitizePinValue(input?.value);

  if (!input) {
    return;
  }

  input.value = pin;
  pinDraft = pin;

  if (pin.length !== 4) {
    pinError = "Enter the 4-digit PIN.";
    currentView = VIEW_STATE.PIN;
    renderCurrentView();
    return;
  }

  pinError = "";
  actionInFlight = true;
  renderCurrentView();

  const refreshedInput = popupViewRoot.querySelector("#pin-code");
  if (refreshedInput instanceof HTMLInputElement) {
    refreshedInput.value = pin;
  }

  try {
    const response = await chrome.runtime.sendMessage({
      type: "add-extra-time",
      domain: site,
      minutes: pendingMinutes,
      pin,
      targetUrl: getResumeTarget()
    });

    if (!response?.ok) {
      throw new Error(cleanError(response?.error || "Could not add extra time."));
    }

    latestStatus = response.status || latestStatus;

    if (latestStatus?.isBlocked) {
      throw new Error("This website is still blocked. Try adding time again.");
    }

    navigateToSite(response.targetUrl);
  } catch (error) {
    actionInFlight = false;
    pinError = cleanError(error);
    currentView = VIEW_STATE.PIN;
    renderCurrentView();

    const nextInput = popupViewRoot.querySelector("#pin-code");

    if (nextInput instanceof HTMLInputElement) {
      nextInput.value = pin;
      pinDraft = pin;
      nextInput.focus();
      nextInput.select();
    }
  }
}

async function confirmStagedMinutes() {
  if (pendingMinutes <= 0 || actionInFlight) {
    return;
  }

  actionInFlight = true;
  renderCurrentView();

  try {
    const response = await chrome.runtime.sendMessage({
      type: "add-extra-time",
      domain: site,
      minutes: pendingMinutes,
      pin: "",
      targetUrl: getResumeTarget()
    });

    if (!response?.ok) {
      throw new Error(cleanError(response?.error || "Could not add extra time."));
    }

    latestStatus = response.status || latestStatus;

    if (latestStatus?.isBlocked) {
      throw new Error("This website is still blocked. Try adding time again.");
    }

    navigateToSite(response.targetUrl);
  } catch (error) {
    actionInFlight = false;

    if (isPinAuthError(error)) {
      currentView = VIEW_STATE.PIN;
      pinDraft = "";
      pinError = "";
      renderCurrentView();
      return;
    }

    currentView = VIEW_STATE.SELECT;
    renderCurrentView();
  }
}

function navigateToSite(targetUrl = "") {
  const nextUrl = normalizeHttpUrl(targetUrl) || getResumeTarget();

  if (nextUrl) {
    window.location.replace(nextUrl);
  }
}

function returnToSelection() {
  if (actionInFlight) {
    return;
  }

  currentView = VIEW_STATE.SELECT;
  pendingMinutes = 0;
  pinDraft = "";
  pinError = "";
  renderCurrentView();
}

function sanitizePinValue(value) {
  return String(value || "").replace(/\D+/g, "").slice(0, 4);
}

function normalizePomodoro(value = {}) {
  const until = Number(value?.until);
  const active = Boolean(value?.active) && Number.isFinite(until) && until > Date.now();

  return {
    active,
    until: active ? until : 0,
    mode: value?.mode === "strict" ? "strict" : "standard",
    whitelist: Array.isArray(value?.whitelist) ? value.whitelist : []
  };
}

function formatMinutes(minutes) {
  const value = Math.max(0, Number(minutes) || 0);
  return `${value} minute${value === 1 ? "" : "s"}`;
}

function getResumeTarget() {
  const queryTarget = new URLSearchParams(window.location.search).get("target");
  const referrerTarget = document.referrer;
  const target = normalizeHttpUrl(queryTarget) || normalizeHttpUrl(referrerTarget);

  if (target) {
    const targetHost = getHostname(target);

    if (targetHost && site && domainMatches(targetHost, site)) {
      return target;
    }
  }

  return site ? `https://${site}/` : "";
}

function normalizeHttpUrl(value) {
  if (typeof value !== "string") {
    return "";
  }

  const text = value.trim();

  if (!/^https?:\/\//i.test(text)) {
    return "";
  }

  try {
    return new URL(text).toString();
  } catch (_error) {
    return "";
  }
}

function getHostname(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "").toLowerCase();
  } catch (_error) {
    return "";
  }
}

function domainMatches(host, domain) {
  return host === domain || host.endsWith(`.${domain}`);
}

function cleanError(error) {
  const message = error && typeof error === "object" && "message" in error
    ? error.message
    : error;

  return String(message || "Something went wrong.").replace(/^Error:\s*/, "");
}

function isPinAuthError(error) {
  const message = cleanError(error);

  return /\bpin\b/i.test(message)
    && /(required|missing|incorrect|invalid|wrong|verify|verification)/i.test(message);
}
